# Changelog for haskell-json-parser

## Unreleased changes
